Dish Master Ubuntu Download Script

Prerequisites

Ensure the following are installed on your Ubuntu system:

    Java Runtime Environment (JRE)

Installation

    1. Unzip the downloaded folder:

    'unzip path/to/downloaded/UbuntuApp.zip -d path/to/extract/'

    
    2. Place yourself on: 

    'cd path/extract/UbuntuApp/'


    3. Make the script executable:

    'chmod +x DMUbuntu_V1.sh'


Execute the script with sudo:

    4. 'sudo ./DMUbuntu_V1.sh'


Note

    Ensure you have the necessary permissions to run scripts with sudo.
    Verify Java is properly installed by running java -version.